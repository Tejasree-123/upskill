The government wants to transform a city into a smart city. The vision is to convert it into a digital and intelligent city to improve the efficiency of services for the citizens. One of the problems faced by the government is traffic.
The government wants to implement a robust traffic system for the city by being prepared for traffic peaks. They want to understand the traffic patterns of the four junctions of the city. Traffic patterns on holidays, as well as on various other occasions during the year, differ from normal working days. This is important to consider for your forecasting.


Data Set Link :
https://drive.google.com/file/d/1y61cDyuO9Zrp1fSchWcAmCxk0B6SMx7X/view?usp=sharing

Depolyment Link:
https://colab.research.google.com/drive/1hJ4Ji3DB0FBwaTDTzFSIewEwgMO3F__7?usp=sharing
